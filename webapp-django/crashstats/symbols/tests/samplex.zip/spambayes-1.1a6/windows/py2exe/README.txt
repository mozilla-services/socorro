This is a py2exe setup script.

Grab the latest version of py2exe from sourceforge.  Ensure you have Python
2.3 or above. Install py2exe. 

Run "setup_all.py"

You should find a dist directory.