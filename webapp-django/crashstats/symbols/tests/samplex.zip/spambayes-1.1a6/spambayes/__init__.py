# package marker.

__version__ = "1.1a6"
__date__ = "April 1, 2010"
